package com.example.howtodoinjava.springhystrixschoolservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.howtodoinjava.springhystrixschoolservice.delegate.PassengerServiceDelegate;

@RestController
public class SchoolServiceController {
	
	@Autowired
	PassengerServiceDelegate passengerServiceDelegate;

	@RequestMapping(value = "/getAirlinesDetails/{airlinesname}", method = RequestMethod.GET)
	public String getStudents(@PathVariable String airlinesname) {
		System.out.println("Going to call passenger service to get data!");
		return passengerServiceDelegate.callPassengerServiceAndGetData(airlinesname);
		
	}
	
}
