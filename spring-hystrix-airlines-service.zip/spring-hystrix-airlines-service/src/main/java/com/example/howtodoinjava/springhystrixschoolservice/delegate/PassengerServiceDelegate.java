package com.example.howtodoinjava.springhystrixschoolservice.delegate;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class PassengerServiceDelegate {
	@Autowired
	RestTemplate restTemplate;
	
	@HystrixCommand(fallbackMethod = "callPassengerServiceAndGetData_Fallback")
	public String callPassengerServiceAndGetData(String airlinesname) {
		System.out.println("Getting School details for " + airlinesname);
		String response = restTemplate
				.exchange("http://localhost:8098/getPassengerDetailsForAirlines/{airlinesname}"
				, HttpMethod.GET
				, null
				, new ParameterizedTypeReference<String>() {
			}, airlinesname).getBody();

		System.out.println("Response Received as " + response + " -  " + new Date());

		return "NORMAL MICROSERVICE FLOW(AIRLINES --> PASSENGER) !!! - AIRLINES NAME -  " + airlinesname + " :::  PASSENGER DETAILS " + response + " -  " + new Date();
	}
	
	
	@SuppressWarnings("unused")
	private String callPassengerServiceAndGetData_Fallback(String airlinesname) {
		
		System.out.println("Passenger Service is down!!! Fallback Route Enabled...");
		
		return "**** CIRCUIT BREAKER ENABLED **** !!!NO RESPONSE FROM PASSENGER SERVICE AT THIS MOMENT. SERVICE WILL BE BACK SHORTLY - " + new Date();
	}

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
}
