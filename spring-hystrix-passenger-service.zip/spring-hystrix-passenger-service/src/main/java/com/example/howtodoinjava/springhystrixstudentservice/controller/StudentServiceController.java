package com.example.howtodoinjava.springhystrixstudentservice.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.howtodoinjava.springhystrixstudentservice.domain.Student;

@RestController
public class StudentServiceController {

	private static Map<String, List<Student>> passengerDB = new HashMap<String, List<Student>>();

	static {
		passengerDB = new HashMap<String, List<Student>>();

		List<Student> lst = new ArrayList<Student>();
		Student std = new Student("Sayom Ghosh", "ABC123");
		lst.add(std);
		std = new Student("Bidhu Sahoo", "DEF456");
		lst.add(std);

		passengerDB.put("JetAirways", lst);

		lst = new ArrayList<Student>();
		std = new Student("Sandeep Mohapatra", "QWE123");
		lst.add(std);
		std = new Student("Nick Carnovile", "ASD456");
		lst.add(std);

		passengerDB.put("Indigo", lst);

	}

	@RequestMapping(value = "/getPassengerDetailsForAirlines/{airlinesname}", method = RequestMethod.GET)
	public List<Student> getStudents(@PathVariable String airlinesname) {
		System.out.println("Getting Passenger details for " + airlinesname);

		List<Student> studentList = passengerDB.get(airlinesname);
		if (studentList == null) {
			studentList = new ArrayList<Student>();
			Student std = new Student("Not Found", "N/A");
			studentList.add(std);
		}
		return studentList;
	}
}
